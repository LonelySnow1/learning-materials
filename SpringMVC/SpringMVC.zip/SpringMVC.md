# 初始SpringMVC
## SpringMVC概述
* springMVC是一种表现层框架技术
  * SpringMVC是一种基于java实现MVC模型的轻量级web框架
  * 优点
    * 使用简单，开发便捷（相比于Servlet）
    * 灵活性强

## 入门案例
### 注解
* ####  @Controller
  * 类型：类注解
  * 位置：SpringMVC控制器类上方
  * 作用：设定核心控制器bean


* #### @RequestMapping
  * 类型:方法注解
  * 位置:SpringMVC控制器方法请求访问路径
  * 作用:设置当前控制器方法请求访问路径
  * 参数:请求访问路径


* #### @ResponseBody
  * 类型：方法注解
  * 位置：SpringMVC控制器方法定义上方
  * 作用：设置当前控制器方法响应内容为当前返回值，无需解析
```java
//2.定义controller
//2.1使用@Controller定义bean
@Controller
public class UserController {
    //2.2设置当前操作的访问路径
    @RequestMapping("/save")
    //2.3设置当前操作的返回值类型
    @ResponseBody
    public String save(){
        System.out.println("user save ...");
        return "{'module':'springmvc'}";
    }
}
```

### 开发总结（1+N）
* 一次性工作：
  * 创建工程，设置服务器，加载工程
  * 导入坐标
  * 创建web容器启动类，设置MVC配置，请求拦截路径
  * 设置核心配置类


* 多次工作：
  * 定义处理的控制器类
  * 定义处理请求的控制器方法，配置映射路径（@RequestMapping）返回json数据（@ResponseBody）

```java
//web容器启动配置类
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.support.AbstractDispatcherServletInitializer;

//4.定义一个servlet容器的启动配置类，在里面添加spring的配置
public class ServletContainersInitConfig extends AbstractDispatcherServletInitializer {
  //加载Springmvc容器配置
  @Override
  protected WebApplicationContext createServletApplicationContext() {
    AnnotationConfigWebApplicationContext ctx = new AnnotationConfigWebApplicationContext();
    ctx.register(SpringMvcConfig.class);
    return ctx;
  }
  //设置哪些请求归属Springmvc处理
  @Override
  protected String[] getServletMappings() {
    return new String[]{"/"};
  }
  //加载Spring容器配置
  @Override
  protected WebApplicationContext createRootApplicationContext() {
     AnnotationConfigWebApplicationContext ctx = new AnnotationConfigWebApplicationContext();
     ctx.register(SpringConfig.class);
     return ctx;
  }
}
```

```java
//MVC配置类

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

//3.创建SpringMvc的配置文件，加载controller对应的bean
@Configuration
@ComponentScan("com.LonelySnow.controller")
public class SpringMvcConfig { }
```

### 入门案例工作流程分析
启动服务器初始化流程
1. 服务器启动，执行web容器启动配置类，初始化web容器
   1. 执行配置类中的createServletApplicationContext方法，创建WebApplicationContext对象
   2. 加载MVC配置类
   3. 执行@ComponentScan，加载对应的bean
   4. 加载控制器类，映射对应的方法
   5. 执行配置类中的getServletMappings方法，定义所有的请求都通过SpringMVC

单次请求过程：
1. 发送请求
   1. 交由MVC处理
   2. 解析请求路径
   3. 匹配对应方法
   4. 执行方法
   5. 有@ResponseBody就将返回值返回给请求方
---
## controller加载控制与业务bean加载控制
* springMVC相关bean 
  * spring控制的bean
    * 业务bean Service
    * 功能bean DataSource等

**功能不同，如何避免Spring错误加载到SpringMVC的bean？**

——加载spring控制的bean的时候排除掉SpringMVC控制的Bean

* SpringMVC相关bean的加载控制
  * 均在对应的controller包内
  * Spring相关bean加载控制
    1. 扫描范围排除掉controller包
    2. 扫描范围精确到对应的service包、dao包 
    3. 不区分，都加载到同一个环境中

### 注解——@ComponentScan
* @ComponentScan
  * 类型：类注解
  * 属性：
    * excludeFilters:排除指定的bean【需要指定type与classes】
    * includeFilters:加载指定的bean【需要指定type与classes】
```java
@Configuration
//方法一 只加载指定包
@ComponentScan({"com.LonelySnow.service", "com.LonelySnow.dao"})
//方法二 排除指定包
@ComponentScan(value = "com.LonelySnow",
        excludeFilters = @ComponentScan.Filter(
                type = FilterType.ANNOTATION,//按注解过滤
                classes = Controller.class//过滤@Controller的注解
        )
)
public class SpringConfig { }
```

**注意事项**
在Main方法中使用bean的时候，若使用register，则需要额外refresh()
```java
public class App {
    public static void main(String[] args) {
//        AnnotationConfigApplicationContext ctx  = new AnnotationConfigApplicationContext(SpringConfig.class);
        AnnotationConfigApplicationContext ctx  = new AnnotationConfigApplicationContext();
        ctx.register(SpringConfig.class);
        ctx.refresh();
        System.out.println(ctx.getBean(UserController.class));
    }
}
```
### 简化web配置类
```java
public class ServletContainersInitConfig extends AbstractAnnotationConfigDispatcherServletInitializer {

    @Override
    protected Class<?>[] getRootConfigClasses() {
        return new Class[]{SpringConfig.class};
    }

    @Override
    protected Class<?>[] getServletConfigClasses() {
        return new Class[]{SpringMvcConfig.class};
    }

    @Override
    protected String[] getServletMappings() {
        return new String[]{"/"};
    }
}
```
---
# 请求与响应 
**团队多人开发，每人设置不同的请求路径，冲突问题如何解决？**

—— 设置模块名作为请求路径前缀

## 请求映射路径
### 注解——@RequestMapping
* @RequestMapping
  * 类型：方法注解，类注解
  * 位置：位于SpringMVC控制器方法定义的商法
  * 作用：设置当前控制器方法的请求访问路径，如果设置在类上就是设置路径前缀
```java
@Controller
@RequestMapping("/book") // 设置访问路径前缀
public class BookController {
    //2.2设置当前操作的访问路径
    @RequestMapping("/save")
    //2.3设置当前操作的返回值类型
    @ResponseBody
    public String save(){
        System.out.println("book save ...");
        return "{'module':'book'}";
    }
}  
```

## 请求方式
### get请求
直接链接后缀参数就行
```
http://localhost/user/commonParam?name=lonelysnow&age=12
```
### post请求
form表单post请求传参，表单参数名与形参变量名相同即可

在Body中的x-www-form-urlencoded设置参数

## 处理请求（不区分get，post）
```java
@Controller
@RequestMapping("/user")
public class UserController {
  @RequestMapping("/commonParam")
  @ResponseBody
  public String commonParam(String name,int age){
    System.out.println("参数传递 ===>" + name);
    System.out.println("参数传递 ===>" + age);
    return "{'name':'commonParam'}";
  }
}
```


### 处理post中文请求乱码问题
为web容器添加过滤器并指定字符集，Spring-web包中提供了专用的字符过滤器
```java
public class ServletContainersInitConfig extends AbstractAnnotationConfigDispatcherServletInitializer {
    //在web配置类中添加如下代码
    @Override
    protected Filter[] getServletFilters() {
    CharacterEncodingFilter filter = new CharacterEncodingFilter();
    filter.setEncoding("UTF-8");
    return new Filter[]{filter};
  }
}
```
### 请求参数-普通类型
* 参数种类
  * 普通参数
    * url地址传参，参数名与形参变量名相同，定义形参即可传参
    * 若不匹配，使用@RequestParam直接指定参数名
  * POJO参数：实体类
    * 请求参数名与形参属性名相同，定义pojo类型即可接收参数
  * 嵌套pojo参数
    * 请求参数名与形参对象属性名相同，按照对象层次结构关系即可接收嵌套pojo属性参数
    * ``` http://localhost/user/pojo?name=lonelysnow&age=13&add.name=beijing&add.city=beijing ```
  * 数组参数
    * 请求参数名与形参对象属性名相同起额请求为多个，定义数组类型形参即可接收参数
    * ```http://localhost/user/hobby?likes=1&likes=2&likes=3```
  * 集合
    * 与数组传参时相同，接收时需要在集合前加上@RequestParam绑定参数关系
    * 不绑定会默认将集合当作对象对立，由于集合是个接口，找不到init方法，报错

  ### 注解——@RequestParam
  * @RequestParam
    * 类型：形参注解
    * 位置：MVC控制器方法形参定义之前
    * 作用：绑定请求参数与处理器方法间的关系
    * 参数：
      * required： 是否为必传参数
      * defaultValue：参数默认值
```java
@Controller
@RequestMapping("/user")
public class UserController {
  @RequestMapping("/commonParam")
  @ResponseBody
  public String commonParam(@RequestParam("username") String name, int age) {
    System.out.println("参数传递 ===>" + name);
    System.out.println("参数传递 ===>" + age);
    return "{'name':'commonParam'}";
  }
}
```
### 请求参数（JSON）
**发送**

Body->raw->JSON

**接收**

1. 
   1. 在pom中导入对应坐标
```xml
      <dependency>
          <groupId>com.fasterxml.jackson.core</groupId>
          <artifactId>jackson-databind</artifactId>
          <version>2.15.0</version>
      </dependency>
```
2. 在SpringMvcConfig配置类中加入注解 @EnableWebMvc ——自动转换功能的支持
   1. 在控制器方法形参前加入@RequestBody

### 日期类型参数传递
对于不同格式的日期参数可以使用@DateTimeFormat来指定接收方式

#### 注解——@DateTimeFormat
* @DateTimeFormat
  * 类型：形参注释
  * 位置：SpringMVC控制器方法形参前面
  * 作用：设定日期时间型数据格式
  * 属性：pattern：日期时间格式字符串

```java
@Controller
@RequestMapping("/user")
public class UserController {
  @RequestMapping("/Date")
  @ResponseBody
  public String Date(Date date,
                     @DateTimeFormat(pattern = "yyyy-MM-dd") Date date1,
                     @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date date2){
    System.out.println("参数传递 ===>" +date);
    System.out.println("参数传递\"yyyy-MM-dd\" ===>" +date1);
    System.out.println("参数传递\"yyyy-MM-dd HH:mm:ss \" ===>" +date2);
    return "{'name':'Date'}";
  }
}
```
#### 类型转换器
* Converter接口
  * 请求参数年龄数据
  * 日期格式转换
  * EnableWebMvc功能之一：根据类型匹配对应的类型转化器

## 响应
* 响应页面 —— 只有在不加请求路径前缀的时候可以用
  * 响应数据
    * 文本数据
    * json数据——直接return 对象就可以，自动转json

类型转换器 

httpMessageConverter

---

# REST风格
## 简介
### REST：表现形式状态转化
  * 传统风格资源描述形式
    * ```https://localhost/user/getById?id=1```
    * ```https://localhost/user/save```
    * REST风格描述形式
      * ```https://localhost/user/1```
      * ```https://localhost/user```
### 优点
    * 隐藏资源的访问行为，无法通过地址得知对资源的何种操作
  * 书写简化
### REST风格简介
  * 按照REST风格访问资源时使用行为动作区分对资源进行了何种操作
    * ```https://localhost/user```     GET（查询）
    * ```https://localhost/user```     PUT（修改）
    * ```https://localhost/user```     POST（新增/保存）
    * ```https://localhost/user```     DELETE（删除）
  * 根据REST风格对资源进行访问称为RESTful

注：
  * 上述行为是约定方式，而不是规范，可以打破
  * 描述的模块名称通常使用复数，也就是加s，表示此类资源

## 入门案例
### 流程
1. 设定http请求动作（动词）
   * 增——post
   * 删——delete
   * 改——put
   * 查——get
2. 设定路径参数（路径变量）

### 注解
* #### @RequestMapping
  * 属性：
    * value：访问路径
    * method：http请求动作，标准动作
* #### @PathVariable
  * 作用：绑定路径参数与处理器方法形参间的关系，要求路径参数名与形参名一一对应

```java
@Controller
public class UserController {

    @RequestMapping(value = "/users",method = RequestMethod.POST)
    @ResponseBody
    public String save(){
        System.out.println("user save ...");
        return "{'module':'user'}";
    }

    @RequestMapping(value = "/users/{id}",method = RequestMethod.DELETE)
    @ResponseBody
    public String delete(@PathVariable Integer id){
        System.out.println("user delete ..."+id);
        return "{'module':'delete'}";
    }
}
```

## 三个注解参数的区分
——@RequestBody  @RequestParam @PathVariable
* 区别
  * @RequestParam 用于接收url地址传参或表单传参
  * @RequestBody 用于接收json数据
  * @PathVariable 用于接收路径参数，使用{参数名称}描述路径参数
* 应用
  * 后期开发中，发送请求超过一个时，以json为主，@RequestBody 
  * 非json数据 @RequestParam
  * 采用RESTful开发，且参数数量较少，使用@PathVariable可传递id值

## RESTful快速开发
### 注解
* #### @RestController
  * 类型：类注解
  * 位置：在RESTful开发控制器类定义上方
  * 作用：等同于@Controller + @ResponseBody
* #### @GetMapping @PostMapping ...
  * 方法注解
  * 作用：代替原有的@RequestMapping
```java
//@Controller
//@ResponseBody
@RestController
@RequestMapping(value = "/books")
public class BookController {

  //    @RequestMapping(method = RequestMethod.POST)
  @PostMapping
  public String save() {
    System.out.println("book save ...");
    return "{'module':'springmvc'}";
  }

  //    @RequestMapping(value = "/{id}",method = RequestMethod.DELETE)
  @DeleteMapping("/{id}")
  public String delete(@PathVariable Integer id) {
    System.out.println("book delete ..." + id);
    return "{'module':'delete'}";
  }
}
```
---
# SSM整合
## 整合流程
  1. 创建工程
  2. SSM整合
     * Spring
       * SpringConfig
     * MyBatis
       * MybatisConfig
       * JdbcConfig
       * jdbc.properties
     * SpringMVC
       * ServletConfig
       * SpringMvcConfig
  3. 功能模块
     * 表与实体类
     * dao（接口+自动代理）
     * service（接口+实现类）
       * 业务层接口测试（整合JUnit）
     * controller
       * 表现层接口测试（PostMan）

### 示例代码
**配置**
* pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>org.example</groupId>
  <artifactId>SSM</artifactId>
  <packaging>war</packaging>
  <version>1.0-SNAPSHOT</version>
  <dependencies>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-webmvc</artifactId>
      <version>5.2.10.RELEASE</version>
    </dependency>

    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-jdbc</artifactId>
      <version>5.2.10.RELEASE</version>
    </dependency>

    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-test</artifactId>
      <version>5.2.10.RELEASE</version>
    </dependency>

    <dependency>
      <groupId>org.mybatis</groupId>
      <artifactId>mybatis</artifactId>
      <version>3.5.6</version>
    </dependency>

    <dependency>
      <groupId>org.mybatis</groupId>
      <artifactId>mybatis-spring</artifactId>
      <version>1.3.0</version>
    </dependency>

    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>5.1.47</version>
    </dependency>

    <dependency>
      <groupId>com.alibaba</groupId>
      <artifactId>druid</artifactId>
      <version>1.1.16</version>
    </dependency>

    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.12</version>
      <scope>test</scope>
    </dependency>

    <dependency>
      <groupId>javax.servlet</groupId>
      <artifactId>javax.servlet-api</artifactId>
      <version>3.1.0</version>
      <scope>provided</scope>
    </dependency>

    <dependency>
      <groupId>com.fasterxml.jackson.core</groupId>
      <artifactId>jackson-databind</artifactId>
      <version>2.9.0</version>
    </dependency>
  </dependencies>

  <build>
    <plugins>
      <plugin>
        <groupId>org.apache.tomcat.maven</groupId>
        <artifactId>tomcat7-maven-plugin</artifactId>
        <version>2.1</version>
        <configuration>
          <port>80</port>
          <path>/</path>
        </configuration>
      </plugin>
    </plugins>
  </build>
</project>

```
* SpringConfig
```java
@Configuration
@ComponentScan({"com.lonelysnow.service"})
@PropertySource("classpath:jdbc.properties")
@Import({JdbcConfig.class,MyBatisConfig.class})
public class SpringConfig {
}
```
* MybatisConfig
```java
public class MyBatisConfig {
    @Bean
    public SqlSessionFactoryBean sqlSessionFactoryBean(DataSource dataSource){
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource);
        factoryBean.setTypeAliasesPackage("com.lonelysnow.domain");
        return factoryBean;
    }
    @Bean
    public MapperScannerConfigurer mapperScannerConfigurer(){
        MapperScannerConfigurer msc = new MapperScannerConfigurer();
        msc.setBasePackage("com.lonelysnow.dao");
        return msc;
    }
}
```
* JdbcConfig
```java
public class JdbcConfig {
  @Value("${jdbc.driver}")
  private String driver;
  @Value("${jdbc.url}")
  private String url;
  @Value("${jdbc.username}")
  private String username;
  @Value("${jdbc.password}")
  private String password;

  @Bean
  public DataSource dataSource(){
    DruidDataSource dataSource = new DruidDataSource();
    dataSource.setDriverClassName(driver);
    dataSource.setUrl(url);
    dataSource.setUsername(username);
    dataSource.setPassword(password);
    return dataSource;
  }
}
```

* jdbc.properties
```properties
jdbc.driver=com.mysql.jdbc.Driver
jdbc.url=jdbc:mysql:///ssm_db?useSSL=false
jdbc.username=root
jdbc.password=123456
```

* ServletConfig
```java
public class ServletConfig extends AbstractAnnotationConfigDispatcherServletInitializer {
  @Override
  protected Class<?>[] getRootConfigClasses() {
    return new Class[]{SpringConfig.class};
  }

  @Override
  protected Class<?>[] getServletConfigClasses() {
    return new Class[]{SpringMvcConfig.class};
  }

  @Override
  protected String[] getServletMappings() {
    return new String[]{"/"};
  }
}
```

* SpringMvcConfig
```java
@Configuration
@ComponentScan("com.lonelysnow.controller")
@EnableWebMvc
public class SpringMvcConfig { }
```

**功能模块**
**模型**
* book
```java
package com.lonelysnow.domain;

public class Book {
    private Integer id;
    private String type;
    private String name;
    private String description;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
```
**数据层标准开发**
* BookDao
```java
public interface BookDao {
    @Insert("insert into tbl_book values(null,#{type},#{name},#{description})")
    public void save(Book book);
    @Update("update tbl_book set type = #{type},name = #{name}, description = #{description} where id = #{id} ")
    public void update(Book book);
    @Delete("delete from tbl_book where id = #{id}")
    public void delete(Integer id);
    @Select("select * from tbl_book where id = #{id}")
    public Book getById(Integer id);
    @Select("select * from tbl_book")
    public List<Book> getAll();

}
```
**业务层标准开发**
* BookService
```java
@Transactional
public interface BookService {

    /**
     * 保存
     * @param book
     * @return
     */
    public boolean save(Book book);

    /**
     * 修改
     * @param book
     * @return
     */
    public boolean update(Book book);

    /**
     * 按id删除
     * @param id
     * @return
     */
    public boolean delete(Integer id);

    /**
     * 按id查找
     * @param id
     * @return
     */
    public Book getById(Integer id);

    /**
     * 查找全部
     * @return
     */
    public List<Book> getAll();
}
```

* BookServiceImpl
```java
@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookDao bookDao;

    @Override
    public boolean save(Book book) {
        bookDao.save(book);
        return true;
    }

    @Override
    public boolean update(Book book) {
        bookDao.update(book);
        return true;
    }

    @Override
    public boolean delete(Integer id) {
        bookDao.delete(id);
        return true;
    }

    @Override
    public Book getById(Integer id) {
        return bookDao.getById(id);
    }

    @Override
    public List<Book> getAll() {
        return bookDao.getAll();
    }
}
```
* BookController
```java
@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping
    public boolean save(@RequestBody Book book) {
        return bookService.save(book);
    }

    @PutMapping
    public boolean update(@RequestBody Book book) {
        return bookService.update(book);
    }

    @DeleteMapping("/{id}")
    public boolean delete(@PathVariable Integer id) {
        return bookService.delete(id);
    }

    @GetMapping("/{id}")
    public Book getById(@PathVariable Integer id) {
        return bookService.getById(id);
    }

    @GetMapping
    public List<Book> getAll() {
        return bookService.getAll();
    }
}
```

**测试接口**
* BookServiceTest
```java
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringConfig.class)
public class BookServiceTest {
    @Autowired
    private BookService bookService;

    @Test
    public void testGetById(){
        Book book = bookService.getById(1);
        System.out.println(book);
    }

    @Test
    public void testGetAll(){
        List<Book> ls = bookService.getAll();
        System.out.println(Arrays.toString(ls.toArray()));
    }
}
```
---
## 表现层数据封装
* 前端接收数据格式——创建结果模型类，封装数据到data中
* 前端接收数据格式——封装特殊消息到message（msg）属性中
### 设置统一数据返回结果类
**没有统一的标准，但需要跟前端沟通好**

**因为是表现层的格式类，所以做好放在Controller类中**
* Result_结果类
  * 根据需求添加getter setter方法和构造方法
```java
public class Result {
    private Object data;
    private Integer code;
    private String msg;
}
```

* Code——注明使用的标准码
```java
public class Code {
    public static final Integer SAVE_OK = 20011;
    public static final Integer DELETE_OK = 20021;
    public static final Integer UPDATE_OK = 20031;
    public static final Integer GET_OK = 20041;

    public static final Integer SAVE_ERR = 20010;
    public static final Integer DELETE_ERR = 20020;
    public static final Integer UPDATE_ERR = 20030;
    public static final Integer GET_ERR = 20040;
}
```
---
## 异常处理器
* 程序开发过程中不可避免的会出现异常
### 异常出现的常见位置与常见诱因
* 框架内部抛出异常 —— 使用不合规
* 数据层抛出异常 —— 外部服务器故障（如：访问服务器超时）
* 业务层抛出异常 —— 因业务逻辑书写错误导致 （如：遍历业务书写操作，导致索引异常）
* 表现层抛出异常 —— 因数据收集，校验等规则导致 （如：不匹配的数据类型间导致异常）
* 工具类抛出异常 —— 因工具类书写不够健壮导致（如： 必要释放的链接长期未释放）

**各个层级都会抛异常，那么处理异常的代码写在那一层呢？**
——所有异常都放到表现层处理

**表现层处理异常，每个方法单独书写，代码书写量巨大且意义不强，如何解决？**
——AOP思想

声明异常处理器——因为是在表现层处理异常，所以最好把处理器放在表现层
* ProjectExceptionConfig
  * 此方法可以根据异常的不同，制作多个方法分别处理对应的异常
```java
@RestControllerAdvice
public class ProjectExceptionConfig {
    @ExceptionHandler(Exception.class)
    public Result doException(Exception ex){
        return new Result(666,null,"抓到异常了喵~");
    }
}
```
---
## 项目异常处理方案  
### 项目异常分类
* 业务异常(BusinessException)
  * 规范的用户行为产生的异常
  * 不规范的用户行为产生的异常
* 系统异常(SystemException)
  * 项目运行过程中可预计且无法避免的异常
* 其他异常(Exception)
  * 编程人员未预期到的异常
### 项目异常处理方案
* 业务异常
  * 发送对应消息传递给用户，提醒操作规范
* 系统异常
  * 发送固定消息传递给用户，安抚用户
  * 发送特定消息给运维人员，提醒维护
  * 记录日志
* 其他异常
  * 发送固定消息给用户，安抚用户
  * 发送特定消息给编程人员，提醒维护（纳入预期范围内）
  * 记录日志

### 具体步骤
#### 1. 自定义项目异常
放在异常文件夹下
* SystemException
```java
public class SystemException extends RuntimeException {
  private Integer code;

  public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }

  public SystemException(Integer code, String message) {
    super(message);
    this.code = code;
  }

  public SystemException(Integer code,String message, Throwable cause) {
    super(message, cause);
    this.code = code;
  }
}
```
#### 2.自定义异常编码
* Code
```java
public class Code {
    public static final Integer SAVE_OK = 20011;
    public static final Integer DELETE_OK = 20021;
    public static final Integer UPDATE_OK = 20031;
    public static final Integer GET_OK = 20041;

    public static final Integer SAVE_ERR = 20010;
    public static final Integer DELETE_ERR = 20020;
    public static final Integer UPDATE_ERR = 20030;
    public static final Integer GET_ERR = 20040;

    public static final Integer SYSTEM_ERR = 50001;
    public static final Integer BUSINESS_ERR = 60001;

}
```

#### 3.触发自定义异常
```java
@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookDao bookDao;
    @Override
    public List<Book> getAll() {
        //将可能出现的异常进行包装，转换为自定义异常
        try{
            int i = 1/0;
        }catch (Exception e){
            throw new SystemException(Code.SYSTEM_ERR,"访问超时喵~",e);
        }
        return bookDao.getAll();
    }
}
```
#### 4.拦截并处理异常
* ProjectExceptionConfig
```java
@RestControllerAdvice
public class ProjectExceptionConfig {
    @ExceptionHandler(Exception.class)
    public Result doException(Exception ex){
        return new Result(666,null,"抓到异常了喵~");
    }
    @ExceptionHandler(SystemException.class)
    public Result SystemException(SystemException ex){
        //记录日志
        //发送消息给运维
        //发送邮件给开发人员
        return new Result(ex.getCode(),null,ex.getMessage());
    }
}
```
---
# 前后台联调
## 页面不加载数据怎么办
* SpringMvcSupport
  * 配置排除路径,放在config路径下
```java
@Configuration
public class SpringMvcSupport extends WebMvcConfigurationSupport {
    //MVC6版本实现接口WebMvcConfigurer,使用方法一样
    @Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/pages/**").addResourceLocations("/pages/");
        registry.addResourceHandler("/css/**").addResourceLocations("/css/");
        registry.addResourceHandler("/js/**").addResourceLocations("/js/");
        registry.addResourceHandler("/plugins/**").addResourceLocations("/plugins/");
    }
}
```
---
# 拦截器
## 拦截器概念
* 拦截器：是一种动态拦截方法调用的机制，在SpringMVC中动态拦截控制器方法的执行
* 作用：
  * 在指定的方法调用前后执行预先设定的代码
  * 阻止原始方法的执行
## 拦截器与过滤器的区别
* 归属不同：Filter是关于天涯Servlet技术,Interceptor属于SpringMVC技术
* 拦截内容不同: Filter对所有访问进行增强，Interceptor仅针对SpringMVC的访问进行增强
## 入门案例
### 使用步骤
1. 声明拦截器的bean，并实现HandlerInterceptor接口（注意：扫描加载bean）
* controller/Interceptor/ProgramInterceptor  
```java
@Component
public class ProjectInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("preHandle");
        return true; //false终止原始操作
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("postHandle");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        System.out.println("afterCompletion");
    }
}
```
2. 定义配置类，继承WebMvcConfigurationSupport，实现addInterceptor方法,并设置拦截路径（注意：扫描加载配置）
* SpringMvcSupport
```java
@Configuration
public class SpringMvcSupport extends WebMvcConfigurationSupport {
    //MVC6版本实现接口WebMvcConfigurer,使用方法一样

    @Autowired
    private ProjectInterceptor projectInterceptor;
    
    @Override
    protected void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(projectInterceptor).addPathPatterns("/books","/books/*");
    }
}
```
**简化开发，直接省略SpringMvcSupport文件，将其功能转移到SpringMvcConfig文件下**

注意：侵入式较强——与Spring强绑定
```java
@Configuration
@ComponentScan({"com.lonelysnow.controller"})
@EnableWebMvc
public class SpringMvcConfig implements WebMvcConfigurer {
    @Autowired
    private ProjectInterceptor projectInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(projectInterceptor).addPathPatterns("/books","/books/*");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/pages/**").addResourceLocations("/pages/");
        registry.addResourceHandler("/css/**").addResourceLocations("/css/");
        registry.addResourceHandler("/js/**").addResourceLocations("/js/");
        registry.addResourceHandler("/plugins/**").addResourceLocations("/plugins/");
    }
}
```

## 拦截器参数
```
public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{}
```
* 前置处理器
  * 参数 
    * request ： 请求对象
    * response ： 响应对象
    * handler ： 被调用的处理器对象，本质上是一个方法对象，对反射技术中的Method对象进行了再包装
  * 返回值
    * 返回值为false，被拦截的处理器将不执行

```
public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {}
```

* 后置处理器
  * 参数
    * modelAndView : 如果处理器执行完具有返回结果，可以读取到对应数据与页面信息，并进行调整

```
public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {}
```
* 完成后处理
  * 参数
    * ex : 执行过程中出现异常对象，可以针对异常情况进行单独处理

## 多拦截器执行顺序
* 当配置多个拦截器时，形成拦截器链
* 拦截器链的运行顺序参照拦截器添加顺序为准
  * preHandle:与配置顺序相同
  * preHandle:与配置顺序相反
  * preHandle:与配置顺序相反
