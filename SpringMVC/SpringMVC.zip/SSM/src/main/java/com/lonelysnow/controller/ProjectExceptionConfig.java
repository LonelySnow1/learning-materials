package com.lonelysnow.controller;

import com.lonelysnow.exception.SystemException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ProjectExceptionConfig {
    @ExceptionHandler(Exception.class)
    public Result doException(Exception ex){
        return new Result(666,null,"抓到异常了喵~");
    }
    @ExceptionHandler(SystemException.class)
    public Result SystemException(SystemException ex){
        //记录日志
        //发送消息给运维
        //发送邮件给开发人员
        return new Result(ex.getCode(),null,ex.getMessage());
    }
}
