package com.lonelysnow.service.impl;

import com.lonelysnow.controller.Code;
import com.lonelysnow.dao.BookDao;
import com.lonelysnow.domain.Book;
import com.lonelysnow.exception.SystemException;
import com.lonelysnow.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookDao bookDao;

    @Override
    public boolean save(Book book) {
        bookDao.save(book);
        return true;
    }

    @Override
    public boolean update(Book book) {
        bookDao.update(book);
        return true;
    }

    @Override
    public boolean delete(Integer id) {
        bookDao.delete(id);
        return true;
    }

    @Override
    public Book getById(Integer id) {
        return bookDao.getById(id);
    }

    @Override
    public List<Book> getAll() {
        //将可能出现的异常进行包装，转换为自定义异常
//        try{
//            int i = 1/0;
//        }catch (Exception e){
//            throw new SystemException(Code.SYSTEM_ERR,"访问超时喵~",e);
//        }

        return bookDao.getAll();
    }
}
