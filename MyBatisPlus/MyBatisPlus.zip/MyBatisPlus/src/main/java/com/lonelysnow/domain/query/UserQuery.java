package com.lonelysnow.domain.query;

import com.lonelysnow.domain.User;
import lombok.Data;

@Data
public class UserQuery extends User {
    private Integer age2;
}
