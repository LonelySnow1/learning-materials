package com.lonelysnow.domain;

import com.baomidou.mybatisplus.annotation.*;
import lombok.*;

@Data
//如果表名和实体类名不一样，可以加上@TableName("对应表名")的注解
@TableName("user")
public class User {
//    @TableId(type = IdType.AUTO)
    private Long id;
    private String name;
    @TableField(value = "password",select = false)
    private String pwd;
    private Integer age;
    private String tel;
    @TableField(select = false)
    private Integer deleted;
    @Version
    private Integer version;
}
