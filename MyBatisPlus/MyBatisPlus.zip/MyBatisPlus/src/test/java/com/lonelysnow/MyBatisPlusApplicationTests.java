package com.lonelysnow;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lonelysnow.dao.UserDao;
import com.lonelysnow.domain.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

@SpringBootTest
class MyBatisPlusApplicationTests {

    @Autowired
    private UserDao userDao;

    @Test
    void add(){
        User user = new User();
        user.setName("LonelySnow");
        user.setPwd("LonelySnow");
        user.setAge(123);
        user.setTel("LonelySnow");
        userDao.insert(user);
    }

    @Test
    void delete(){
        LambdaQueryWrapper<User> qw = new LambdaQueryWrapper<>();
        qw.eq(User::getName,"lonelysnow");
        userDao.delete(qw);
    }


    @Test
    void testGetAll() {

        LambdaQueryWrapper<User> qw = new LambdaQueryWrapper<>();
//        qw.eq(User::getName,"lonelysnow").eq(User::getPwd,"123456879");
        List<User> user = userDao.selectList(null);
        System.out.println(user);
    }


    @Test
    void update(){
//        User user = new User();
//        user.setId(2L);
//        user.setName("snow");
//        user.setVersion(1);
//        userDao.updateById(user);
        //1. 修改前先查询要修改的数据
        User user = userDao.selectById(2L);
        //2.将想要修改的属性值传进去
        user.setName("snow");
        userDao.updateById(user);
    }
}
